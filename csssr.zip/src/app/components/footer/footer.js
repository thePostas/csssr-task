import React from "react";
import { Date } from '../../containers/date'
export const FooterComponent = props => {
    return (
        <div className={"footer footer_position"}>
            <Date/>
        </div>
    );
};
