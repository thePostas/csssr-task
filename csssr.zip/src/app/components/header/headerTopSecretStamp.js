import React from "react";

export const HeaderTopSecret = props => {
    return (
        <div className={"header__stamp"}>
            <img src={'../src/app/img/top_secret.png'} width={252} height={106}/>
        </div>
    );
};
