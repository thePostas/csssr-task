import React from "react";

export const MainContentTitle = props => {
    return (
        <div className="main-content__title main-content__title_position">
            <img className={'main-content__title-image'} src={'../src/app/img/main_content_logo.png'} alt={'ДЕЛО'} width={219} height={110} />
        </div>
    );
};